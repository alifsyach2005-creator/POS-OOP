package com.traktirkopi;

public class Produk {
    private final String nama;
    private final double harga;
    private final String imagePath;

    public Produk(String nama, double harga, String imagePath) {
        this.nama = nama;
        this.harga = harga;
        this.imagePath = imagePath;
    }

    // Getter
    public String getNama() { return nama; }
    public double getHarga() { return harga; }
    public String getImagePath() { return imagePath; }
}
