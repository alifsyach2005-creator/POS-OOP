package com.traktirkopi;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class PaymentController {

    @FXML 
    private Label totalBayarLabel;
    
    private String selectedMethod = "";

    public void setTotal(int total) {
        if (totalBayarLabel != null) {
            totalBayarLabel.setText("Rp " + String.format("%,d", total).replace(',', '.'));
        }
    }

    public String getSelectedMethod() {
        return selectedMethod;
    }
    
    @FXML
    private void processPayment() {
        this.selectedMethod = "Selesai";
        close();
    }

    @FXML
    private void handleTunai() {
        this.selectedMethod = "Tunai";
        close(); 
    }

    @FXML
    private void handleQRIS() {
        this.selectedMethod = "QRIS";
        close(); 
    }
    
    @FXML
    private void handleBatal() {
        // Memberikan feedback ke console saat batal
        System.out.println("User membatalkan transaksi.");
        this.selectedMethod = ""; 
        close(); 
    }

    /**
     * PERBAIKAN: Pastikan menggunakan @FXML dan visibilitas public.
     * Jika di FXML baris 28 tertulis onAction="#close", 
     * maka method ini WAJIB ada di sini.
     */
    @FXML
    public void close() {
        try {
            if (totalBayarLabel != null && totalBayarLabel.getScene() != null) {
                Stage stage = (Stage) totalBayarLabel.getScene().getWindow();
                stage.close();
            }
        } catch (Exception e) {
            System.err.println("Gagal menutup popup: " + e.getMessage());
        }
    }
}