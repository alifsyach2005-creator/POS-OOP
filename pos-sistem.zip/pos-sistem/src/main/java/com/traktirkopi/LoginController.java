package com.traktirkopi;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    @FXML
private void handleLogin(ActionEvent event) {
    System.out.println("Mencoba Login..."); // Log untuk cek apakah tombol merespons
    if (usernameField.getText().equals("admin") && passwordField.getText().equals("1234")) {
        try {
            System.out.println("Pindah ke halaman Primary...");
            App.setRoot("primary");
        } catch (Exception e) {
            System.out.println("EROR PINDAH HALAMAN: " + e.getMessage());
        }
    }
}
}


