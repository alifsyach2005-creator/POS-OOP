package com.traktirkopi;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.scene.paint.Color;
import javafx.geometry.Pos;

public class SecondaryController {

    // Komponen UI Utama
    @FXML private GridPane menuGrid;
    @FXML private ScrollPane catalogScroll;
    @FXML private VBox cartContainer, historyPanel, backofficePanel;
    @FXML private Label totalLabel, categoryLabel;
    @FXML private TextField customerNameField; 

    // Tombol Navigasi
    @FXML private Button btnAll, btnKopi, btnNonKopi, btnMakanan, btnCemilan, btnHistory, btnBackoffice;

    // Tabel History
    @FXML private TableView<Transaction> historyTable;
    @FXML private TableColumn<Transaction, String> colID, colPelanggan, colWaktu, colTotal, colMetode;

    // Laporan Backoffice
    @FXML private Label lblTotalCash, lblTotalQRIS, lblTotalGabungan, lblJumlahTransaksi;

    private final ObservableList<Transaction> transactionData = FXCollections.observableArrayList();
    private int totalBelanja = 0;
    private int transactionCounter = 1;

    @FXML
    public void initialize() {
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colPelanggan.setCellValueFactory(new PropertyValueFactory<>("pelanggan"));
        colWaktu.setCellValueFactory(new PropertyValueFactory<>("waktu"));
        colTotal.setCellValueFactory(new PropertyValueFactory<>("total"));
        colMetode.setCellValueFactory(new PropertyValueFactory<>("metode"));
        historyTable.setItems(transactionData);

        customerNameField.setPromptText("Masukkan Nama Pelanggan...");
        
        showAllMenu(); 
    }

    // --- LOGIKA PEMBAYARAN ---

    @FXML
    private void handlePayment() {
        String customerName = customerNameField.getText().trim();

        if (totalBelanja == 0) {
            showAlert("Peringatan", "Keranjang belanja masih kosong!", Alert.AlertType.WARNING);
            return;
        }

        if (customerName.isEmpty()) {
            customerNameField.setStyle("-fx-border-color: #e74c3c; -fx-border-width: 2px;");
            customerNameField.requestFocus();
            showAlert("Data Tidak Lengkap", "Silakan masukkan nama pelanggan terlebih dahulu.", Alert.AlertType.ERROR);
            return;
        }

        try {
            customerNameField.setStyle("");
            URL fxmlLoc = getClass().getResource("payment.fxml");
            FXMLLoader loader = new FXMLLoader(fxmlLoc);
            Parent root = loader.load();
            
            PaymentController pc = loader.getController();
            pc.setTotal(totalBelanja);

            Stage popup = new Stage();
            popup.initModality(Modality.APPLICATION_MODAL);
            popup.initStyle(StageStyle.UNDECORATED);
            popup.initOwner(totalLabel.getScene().getWindow());
            
            Scene scene = new Scene(root);
            scene.setFill(Color.TRANSPARENT);
            popup.setScene(scene);
            
            popup.showAndWait();

            String metode = pc.getSelectedMethod();
            if (metode != null && !metode.isEmpty()) {
                saveToHistory(customerName, metode);
                clearCart();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveToHistory(String customerName, String metode) {
        String waktu = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String totalTxt = "Rp " + String.format("%,d", totalBelanja).replace(',', '.');
        
        transactionData.add(new Transaction(
            "TRX-" + (1000 + transactionCounter++), 
            customerName, 
            waktu, 
            totalTxt, 
            metode
        ));
    }

    private void clearCart() {
        cartContainer.getChildren().clear();
        customerNameField.clear();
        totalBelanja = 0;
        updateTotalDisplay();
    }

    // --- MANAJEMEN MENU & KATEGORI ---

    @FXML private void showAllMenu() { renderCategory("Semua Menu", btnAll, getAllItems()); }
    @FXML private void showKopi() { renderCategory("Kategori: Kopi", btnKopi, getKopiItems()); }
    @FXML private void showNonKopi() { renderCategory("Kategori: Non-Kopi", btnNonKopi, getNonKopiItems()); }
    
    // Perbaikan: Gunakan renderCategory agar konsisten dan tidak error
    @FXML private void showMakanan() { renderCategory("Kategori: Makanan", btnMakanan, getMakananItems()); }
    @FXML private void showCemilan() { renderCategory("Kategori: Cemilan", btnCemilan, getCemilanItems()); }
    
    private void renderCategory(String title, Button activeBtn, List<MenuItemData> items) {
        hideAllPanels();
        catalogScroll.setVisible(true);
        catalogScroll.setManaged(true);
        categoryLabel.setText(title);
        setActiveStyle(activeBtn);
        
        menuGrid.getChildren().clear();
        int columns = 3;
        for (int i = 0; i < items.size(); i++) {
            addMenuItemToGrid(items.get(i).nama, items.get(i).harga, i % columns, i / columns);
        }
    }

    private void addMenuItemToGrid(String nama, int harga, int col, int row) {
        VBox card = new VBox(10);
        card.setAlignment(Pos.CENTER);
        card.getStyleClass().add("menu-card");
        card.setStyle("-fx-border-color: #ddd; -fx-padding: 15; -fx-background-color: white; -fx-background-radius: 8;");
        
        Label lblNama = new Label(nama);
        lblNama.setStyle("-fx-font-weight: bold;");
        Label lblHarga = new Label("Rp " + String.format("%,d", harga).replace(',', '.'));
        
        Button btnAdd = new Button("Tambah");
        btnAdd.getStyleClass().add("btn-tambah");
        btnAdd.setOnAction(e -> addToCart(nama, harga));
        
        card.getChildren().addAll(lblNama, lblHarga, btnAdd);
        menuGrid.add(card, col, row);
    }

    private void addToCart(String nama, int harga) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setStyle("-fx-padding: 5; -fx-border-color: #444; -fx-border-width: 0 0 1 0;");
        
        Label nl = new Label(nama); nl.setStyle("-fx-text-fill: white;"); nl.setPrefWidth(110);
        Label hl = new Label("Rp" + harga); hl.setStyle("-fx-text-fill: #FFD700;");
        
        Button del = new Button("✕");
        del.setStyle("-fx-background-color: transparent; -fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        del.setOnAction(e -> {
            cartContainer.getChildren().remove(row);
            totalBelanja -= harga;
            updateTotalDisplay();
        });

        row.getChildren().addAll(nl, hl, del);
        cartContainer.getChildren().add(row);
        
        totalBelanja += harga;
        updateTotalDisplay();
    }

    // --- HELPER UI ---

    private void hideAllPanels() {
        catalogScroll.setVisible(false); catalogScroll.setManaged(false);
        historyPanel.setVisible(false); historyPanel.setManaged(false);
        backofficePanel.setVisible(false); backofficePanel.setManaged(false);
    }

    private void setActiveStyle(Button target) {
        // Menggunakan style dari CSS Luxury Anda
        Button[] navs = {btnAll, btnKopi, btnNonKopi, btnMakanan, btnCemilan, btnHistory, btnBackoffice};
        for (Button b : navs) { 
            if (b != null) b.getStyleClass().remove("active-nav"); 
        }
        if (target != null) target.getStyleClass().add("active-nav");
    }

    private void updateTotalDisplay() {
        totalLabel.setText("Rp " + String.format("%,d", totalBelanja).replace(',', '.'));
    }

    private void showAlert(String title, String content, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    // --- DATA DUMMY ---
    private List<MenuItemData> getAllItems() { 
        return List.of(
            new MenuItemData("Espresso", 15000), 
            new MenuItemData("Nasi Goreng", 35000), 
            new MenuItemData("Ice Tea", 10000),
            new MenuItemData("Americano", 20000),
            new MenuItemData("Latte", 25000),
            new MenuItemData("Matcha", 25000),
            new MenuItemData("Mie Goreng", 30000),
            new MenuItemData("Nasi Kulit", 33000),
            new MenuItemData("Singkong Keju", 20000),
            new MenuItemData("Pisang Coklat", 20000),
            new MenuItemData("Ketan Susu", 25000)
        ); 
    }
    private List<MenuItemData> getKopiItems() { 
        return List.of(new MenuItemData("Espresso", 15000), new MenuItemData("Americano", 20000), new MenuItemData("Latte", 25000)); 
    }
    private List<MenuItemData> getNonKopiItems() { 
        return List.of(new MenuItemData("Ice Tea", 10000), new MenuItemData("Matcha", 25000)); 
    }
    private List<MenuItemData> getMakananItems() { 
        return List.of(new MenuItemData("Nasi Goreng", 35000), new MenuItemData("Mie Goreng", 30000), new MenuItemData("Nasi Kulit", 33000)); 
    }
    private List<MenuItemData> getCemilanItems() { 
        return List.of(new MenuItemData("Singkong Keju", 20000), new MenuItemData("Pisang Coklat", 20000), new MenuItemData("Ketan Susu", 25000)); 
    }

    @FXML private void showHistory() { hideAllPanels(); setActiveStyle(btnHistory); historyPanel.setVisible(true); historyPanel.setManaged(true); }
    @FXML private void showBackoffice() { hideAllPanels(); setActiveStyle(btnBackoffice); backofficePanel.setVisible(true); backofficePanel.setManaged(true); updateSummary(); }
    @FXML private void switchToPrimary() throws IOException { App.setRoot("primary"); }
    
    private void updateSummary() {
        long cash = 0, qris = 0;
        for (Transaction t : transactionData) {
            long val = Long.parseLong(t.getTotal().replaceAll("[^0-9]", ""));
            if (t.getMetode().equalsIgnoreCase("Tunai")) cash += val; else qris += val;
        }
        lblTotalCash.setText("Rp " + String.format("%,d", cash).replace(',', '.'));
        lblTotalQRIS.setText("Rp " + String.format("%,d", qris).replace(',', '.'));
        lblTotalGabungan.setText("Rp " + String.format("%,d", cash + qris).replace(',', '.'));
        lblJumlahTransaksi.setText(transactionData.size() + " Transaksi");
    }

    private static class MenuItemData { 
        String nama; int harga; 
        MenuItemData(String n, int h) { this.nama = n; this.harga = h; } 
    }
}