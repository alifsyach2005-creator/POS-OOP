package com.traktirkopi;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Model class untuk menyimpan data transaksi POS.
 * Menggunakan StringProperty agar kompatibel dengan TableView JavaFX.
 */
public class Transaction {
    private final StringProperty id;
    private final StringProperty pelanggan; // Kolom baru untuk Nama Pelanggan
    private final StringProperty waktu;
    private final StringProperty total;
    private final StringProperty metode;

    // Constructor dengan 5 Parameter sesuai kebutuhan SecondaryController terbaru
    public Transaction(String id, String pelanggan, String waktu, String total, String metode) {
        this.id = new SimpleStringProperty(id);
        this.pelanggan = new SimpleStringProperty(pelanggan);
        this.waktu = new SimpleStringProperty(waktu);
        this.total = new SimpleStringProperty(total);
        this.metode = new SimpleStringProperty(metode);
    }

    // --- GETTER & SETTER (Required for PropertyValueFactory) ---

    public String getId() { return id.get(); }
    public StringProperty idProperty() { return id; }
    public void setId(String value) { id.set(value); }

    public String getPelanggan() { return pelanggan.get(); }
    public StringProperty pelangganProperty() { return pelanggan; }
    public void setPelanggan(String value) { pelanggan.set(value); }

    public String getWaktu() { return waktu.get(); }
    public StringProperty waktuProperty() { return waktu; }
    public void setWaktu(String value) { waktu.set(value); }

    public String getTotal() { return total.get(); }
    public StringProperty totalProperty() { return total; }
    public void setTotal(String value) { total.set(value); }

    public String getMetode() { return metode.get(); }
    public StringProperty metodeProperty() { return metode; }
    public void setMetode(String value) { metode.set(value); }
}