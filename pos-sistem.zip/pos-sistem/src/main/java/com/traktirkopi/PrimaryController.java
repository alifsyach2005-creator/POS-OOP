package com.traktirkopi;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class PrimaryController {

    @FXML
    private Button primaryButton;

    @FXML
    private void switchToSecondary() {
        try {
            // Logika perpindahan halaman yang stabil
            App.setRoot("secondary");
        } catch (IOException e) {
            System.err.println("Sistem gagal berpindah ke halaman secondary: " + e.getMessage());
        }
    }

    @FXML
    public void initialize() {
        // Tempat untuk inisialisasi data produk atau tabel saat aplikasi dibuka
        System.out.println("Sistem POS Siap Digunakan.");
    }
}